##########
Deep Sleep
##########

About
-----

.. note:: This is a work in progress project and this section is still missing. If you want to contribute, please see the `Contributions Guide <../contributing.html>`_.

Examples
--------

To get started with Hall sensor, you can try:

ExternalWakeUp
**************

.. literalinclude:: ../../../libraries/ESP32/examples/DeepSleep/ExternalWakeUp/ExternalWakeUp.ino
    :language: arduino

Timer Wake Up
*************

.. literalinclude:: ../../../libraries/ESP32/examples/DeepSleep/TimerWakeUp/TimerWakeUp.ino
    :language: arduino
